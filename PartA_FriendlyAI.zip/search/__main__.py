from search.main import main

main()
